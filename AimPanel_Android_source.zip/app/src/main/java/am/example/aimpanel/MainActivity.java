package am.example.aimpanel;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.rgb(243, 248, 252));
        panel.setPadding(dp(22), dp(36), dp(22), dp(20));

        TextView title = label("AimPanel", 30, Color.rgb(15, 42, 62));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        panel.addView(title);

        TextView sub = label("Плавающая панель и тренировочный прицел без ROOT", 16, Color.DKGRAY);
        sub.setPadding(0, dp(10), 0, dp(15));
        panel.addView(sub);

        status = label("", 15, Color.rgb(11, 102, 112));
        status.setPadding(0, 0, 0, dp(16));
        panel.addView(status);

        addButton(panel, "1. Разрешить отображение поверх приложений", () -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent in = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(in);
            } else {
                Toast.makeText(this, "Разрешение уже предоставлено", Toast.LENGTH_SHORT).show();
            }
        });

        addButton(panel, "2. Показать плавающую кнопку", () -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала разрешите отображение поверх приложений", Toast.LENGTH_LONG).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
            }
            Intent in = new Intent(this, OverlayService.class);
            in.setAction(OverlayService.ACTION_START);
            startForegroundService(in);
            Toast.makeText(this, "Плавающая кнопка запущена", Toast.LENGTH_SHORT).show();
        });

        addButton(panel, "3. Запустить Call of Duty: Mobile", this::openGame);

        addButton(panel, "Остановить панель", () -> {
            Intent in = new Intent(this, OverlayService.class);
            in.setAction(OverlayService.ACTION_STOP);
            startService(in);
        });

        TextView hint = label(
                "Использование: коснитесь плавающей кнопки, чтобы показать или скрыть прицел. " +
                "Удерживайте и перетаскивайте кнопку для перемещения. " +
                "Приложение НЕ наводит оружие автоматически и НЕ отслеживает игроков. " +
                "Из-за правил игры используйте сторонние наложения на свой риск.",
                14, Color.DKGRAY);
        hint.setPadding(0, dp(20), 0, 0);
        panel.addView(hint);
        setContentView(panel);
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) status.setText("Поверх приложений: " +
                (Settings.canDrawOverlays(this) ? "РАЗРЕШЕНО" : "НЕ РАЗРЕШЕНО"));
    }

    private void openGame() {
        String[] packages = {"com.activision.callofduty.shooter", "com.garena.game.codm"};
        for (String pkg : packages) {
            Intent in = getPackageManager().getLaunchIntentForPackage(pkg);
            if (in != null) {
                startActivity(in);
                return;
            }
        }
        Toast.makeText(this, "Игра не найдена. Откройте Call of Duty: Mobile вручную.", Toast.LENGTH_LONG).show();
    }

    private void addButton(LinearLayout parent, String text, Runnable click) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(8);
        parent.addView(button, p);
        button.setOnClickListener(v -> click.run());
    }

    private TextView label(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        return t;
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
}
