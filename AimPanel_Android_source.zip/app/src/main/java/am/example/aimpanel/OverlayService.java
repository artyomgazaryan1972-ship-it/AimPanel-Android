package am.example.aimpanel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class OverlayService extends Service {
    static final String ACTION_START = "am.example.aimpanel.START";
    static final String ACTION_STOP = "am.example.aimpanel.STOP";
    private WindowManager wm;
    private TextView bubble;
    private View reticle;
    private WindowManager.LayoutParams bubbleParams;
    private boolean reticleShown = false;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(123, makeNotification());
        if (bubble == null) addBubble();
        return START_STICKY;
    }

    private Notification makeNotification() {
        String channel = "aimpanel_running";
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                channel, "AimPanel работает", NotificationManager.IMPORTANCE_LOW));

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, OverlayService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, channel)
                .setContentTitle("AimPanel активна")
                .setContentText("Нажмите кнопку на экране для переключения прицела")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stopPi)
                .setOngoing(true)
                .build();
    }

    private void addBubble() {
        bubble = new TextView(this);
        bubble.setText("+");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(25);
        bubble.setGravity(Gravity.CENTER);
        applyBubbleColor(false);
        bubbleParams = new WindowManager.LayoutParams(dp(54), dp(54),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(12);
        bubbleParams.y = dp(190);
        wm.addView(bubble, bubbleParams);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int originX, originY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        originX = bubbleParams.x;
                        originY = bubbleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int x = originX + Math.round(event.getRawX() - downX);
                        int y = originY + Math.round(event.getRawY() - downY);
                        if (Math.abs(x - originX) > dp(7) || Math.abs(y - originY) > dp(7)) moved = true;
                        if (moved) {
                            bubbleParams.x = Math.max(0, x);
                            bubbleParams.y = Math.max(0, y);
                            wm.updateViewLayout(bubble, bubbleParams);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) toggleReticle();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void applyBubbleColor(boolean active) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(active ? Color.rgb(12, 121, 87) : Color.rgb(25, 45, 65));
        shape.setCornerRadius(dp(99));
        shape.setStroke(dp(2), Color.rgb(64, 218, 228));
        bubble.setBackground(shape);
    }

    private void toggleReticle() {
        if (reticleShown) {
            if (reticle != null) {
                wm.removeView(reticle);
                reticle = null;
            }
            reticleShown = false;
        } else {
            reticle = new ReticleView();
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                    dp(72), dp(72), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            p.gravity = Gravity.CENTER;
            p.alpha = 0.7f; // Android 12+ untrusted-touch opacity limit is 0.8.
            wm.addView(reticle, p);
            reticleShown = true;
        }
        applyBubbleColor(reticleShown);
    }

    private class ReticleView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ReticleView() { super(OverlayService.this); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            paint.setColor(Color.rgb(55, 241, 198));
            paint.setStrokeWidth(dp(2));
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawLine(cx - dp(25), cy, cx - dp(8), cy, paint);
            canvas.drawLine(cx + dp(8), cy, cx + dp(25), cy, paint);
            canvas.drawLine(cx, cy - dp(25), cx, cy - dp(8), paint);
            canvas.drawLine(cx, cy + dp(8), cx, cy + dp(25), paint);
            canvas.drawCircle(cx, cy, dp(2), paint);
        }
    }

    @Override public void onDestroy() {
        if (reticle != null) { wm.removeView(reticle); reticle = null; }
        if (bubble != null) { wm.removeView(bubble); bubble = null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
}
